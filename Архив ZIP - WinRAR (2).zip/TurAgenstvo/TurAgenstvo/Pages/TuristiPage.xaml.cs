﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TurAgenstvo.Models;

namespace TurAgenstvo.Pages
{
    /// <summary>
    /// Логика взаимодействия для TuristiPage.xaml
    /// </summary>
    public partial class TuristiPage : Page
    {
        public TuristiPage()
        {
            InitializeComponent();
            DGKlient.ItemsSource = App.DB.Klient.ToList();
            Refresh();
        }

        private void btnAddTur_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddTuristi(new Klient()));
        }

        private void btnSbros_Click(object sender, RoutedEventArgs e)
        {
            TBPhone.Text = "";
            TBEmail.Text = "";
            TBFIO.Text = "";
            Refresh();
        }

        private void btnRedactionTur_Click(object sender, RoutedEventArgs e)
        {
            var selectedKlient = DGKlient.SelectedItem as Klient;
            if (selectedKlient == null)
            {
                MessageBox.Show("Выберите Клиента");
                return;
            }
            NavigationService.Navigate(new AddTuristi(selectedKlient));
        }
        private void Refresh()
        {
            
            var filtred = App.DB.Klient.ToList();
            var searchText1 = TBEmail.Text.ToLower();
            var searchText2 = TBPhone.Text.ToLower();
            var searchText = TBFIO.Text.ToLower();

            if (!string.IsNullOrWhiteSpace(searchText))
                filtred = filtred.Where(x => x.FIO.ToString().Contains(searchText)).ToList();
            DGKlient.ItemsSource = filtred.ToList();
            if (!string.IsNullOrWhiteSpace(searchText1))
                filtred = filtred.Where(x => x.Email.ToString().Contains(searchText1)).ToList();
            DGKlient.ItemsSource = filtred.ToList();
            if (!string.IsNullOrWhiteSpace(searchText2))
                filtred = filtred.Where(x => x.Phone.ToString().Contains(searchText2)).ToList();
            DGKlient.ItemsSource = filtred.ToList();

        }
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var deleteKlient = DGKlient.SelectedItem as Klient;
            if (deleteKlient == null)
            {
                MessageBox.Show("Выберите Клиента");
                return;
            }
            App.DB.Klient.Remove(deleteKlient);
            App.DB.SaveChanges();
            DGKlient.ItemsSource = App.DB.Klient.ToList();
           
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            DGKlient.ItemsSource = App.DB.Klient.ToList();
        }

        private void TBEmail_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh();
        }

        private void TBPhone_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh();
        }

        private void TBFIO_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh();
        }
    }
}

