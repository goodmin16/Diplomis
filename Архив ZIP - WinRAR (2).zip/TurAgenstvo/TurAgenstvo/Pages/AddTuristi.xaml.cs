﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TurAgenstvo.Models;

namespace TurAgenstvo.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddTuristi.xaml
    /// </summary>
    public partial class AddTuristi : Page
    {
        Klient contextKlient;
        public AddTuristi(Klient klient)
        {
            InitializeComponent();
            contextKlient = klient;
            DataContext = contextKlient;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void btnAddKlient_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            if (contextKlient.FIO.Length > 100)
                errorMessage += "Слишком длинное ФИО\n";
            if (contextKlient.Phone.Value > 11)
                errorMessage += "Не праивльный формат номера\n";
            if (contextKlient.Email.Length > 500)
                errorMessage += "Слишком длинное Email\n";
            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage);
                return;
            }
            App.DB.SaveChanges();
            if (contextKlient.id == 0)
                App.DB.Klient.Add(contextKlient);
            App.DB.SaveChanges();
            NavigationService.GoBack();
            {
                MessageBox.Show("Клиет успешно добавлен!");
            }
        }
    }
}
