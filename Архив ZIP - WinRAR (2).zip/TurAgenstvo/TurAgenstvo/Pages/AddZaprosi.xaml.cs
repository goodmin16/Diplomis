﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TurAgenstvo.Models;

namespace TurAgenstvo.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddZaprosi.xaml
    /// </summary>
    public partial class AddZaprosi : Page
    {
        Applicatio contextApplicatio;
        public AddZaprosi(Applicatio applicatio)
        {
            
            InitializeComponent();
            CBSotrudnik.ItemsSource = App.DB.Sotrudnik.ToList();
            CBTur.ItemsSource = App.DB.Turi.ToList();
            CBTurist.ItemsSource = App.DB.Klient.ToList();
            contextApplicatio = applicatio;
            DataContext = contextApplicatio;
        }

        private void btnAddAplication_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            if (contextApplicatio.Price < 10000)
                errorMessage += "Цена должна быть не меньше 10000\n ";
            if (contextApplicatio.Discount < 1000 || contextApplicatio.Discount > 100000)
                errorMessage += "Скидка должна быть не меньше 1000 и не больше 100000\n ";
            if (contextApplicatio.ArrivalDate < DateTime.Now)
                errorMessage += "Дата заказа не может быть меньше или равно сегоднящнего дня\n ";
            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage);
                return;
            }
            App.DB.SaveChanges();
            if (contextApplicatio.id == 0)
                App.DB.Applicatio.Add(contextApplicatio);
            App.DB.SaveChanges();
            NavigationService.GoBack();
            {
                MessageBox.Show("Заявка успешно добавлена");
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
